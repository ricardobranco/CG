#ifndef _CAD
#define _CAD

void banco_alto(float tamanho);
void banco_balcao(float tamanho);
void banco_sofa(float tamanho);

#endif