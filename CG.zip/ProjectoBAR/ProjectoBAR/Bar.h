#ifndef _BAR
#define _BAR


void chao(float scale);
void paredes(float scale);
void tecto(float scale);





#endif
