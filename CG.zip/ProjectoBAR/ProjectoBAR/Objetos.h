#ifndef _OBJ
#define _OBJ



void sofa(float comp,float alt,float larg);

void Candi1(float tamanho);

void Candi2(float tamanho);

void Candi3(float tamanho);

void Candi4(float tamanho, int ncamadas, int nlamp);

void Candi5(float tamanho);

void Mesacafe(float raio, float alt);


#endif
